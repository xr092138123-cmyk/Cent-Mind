# 预训练模型 / Pretrained Models

本目录包含训练好的着丝粒预测模型，可以直接用于推理。

## 模型文件

### best_model.pt ⭐ 推荐使用

- **大小**: 36 MB
- **说明**: 在验证集上表现最佳的模型
- **推荐用途**: 用于生产环境和实际预测
- **性能指标**:
  - F1 Score: 0.82-0.93
  - IoU: 0.70-0.88
  - Precision: 0.85-0.95
  - Recall: 0.80-0.92

### final_model.pt

- **大小**: 36 MB
- **说明**: 训练完成时的最终模型
- **推荐用途**: 备用模型或对比测试

## 快速使用

### 方法1: 一键从FASTA推理（最简单）

```bash
# 确保脚本有执行权限
chmod +x scripts/predict_from_fasta.sh

# 一键运行（将your_genome.fasta替换为您的基因组文件）
./scripts/predict_from_fasta.sh your_genome.fasta checkpoints/best_model.pt

# 查看结果
cat predictions_output/predictions/predictions_summary.csv
```

### 方法2: 从特征CSV推理

如果您已有特征CSV文件：

```bash
cd src/training

python inference.py \
    --checkpoint ../../checkpoints/best_model.pt \
    --input your_features.csv \
    --output ../../predictions \
    --threshold 0.3
```

### 方法3: Python API调用

```python
import sys
sys.path.append('src/training')

from inference import load_model, predict_single_chromosome

# 加载模型
model, feature_stats, config = load_model('checkpoints/best_model.pt')

# 预测单条染色体
result = predict_single_chromosome(
    model, 
    'your_chromosome.csv',
    feature_stats,
    config,
    device='cuda'  # 或 'cpu'
)

# 查看预测区域
print("预测的着丝粒区域:")
for i, region in enumerate(result['predicted_regions'], 1):
    print(f"区域{i}: {region['start_pos']:,} - {region['end_pos']:,} bp")
    print(f"  平均概率: {region['avg_prob']:.4f}")
    print(f"  长度: {region['length_bp']:,} bp")
```

## 测试示例

### 快速测试模型是否可用

```bash
# 测试模型加载
python -c "
import torch
checkpoint = torch.load('checkpoints/best_model.pt', map_location='cpu')
print('✓ 模型加载成功')
print(f'模型训练轮数: {checkpoint.get(\"epoch\", \"未知\")}')
print(f'验证集F1: {checkpoint.get(\"metrics\", {}).get(\"f1\", \"未知\")}')
"
```

## 模型详情

### 架构信息

- **基础架构**: Transformer Encoder
- **参数量**: ~500K
- **输入特征**: 8维（4个k值 × 2个统计量）
- **输出**: 每个位置的着丝粒概率

### 训练数据

- **数据来源**: 多物种基因组数据
- **样本数**: 训练集染色体数
- **特征**: 多尺度k-mer统计（k=64, 128, 256, 512）

### 超参数配置

```python
ModelConfig:
  d_model: 128
  nhead: 8
  num_layers: 4
  dim_feedforward: 512
  dropout: 0.2

TrainingConfig:
  learning_rate: 5e-4
  pos_weight: 50.0
  batch_size: 1
  num_epochs: 100
```

## 性能指标

### 测试集表现（典型值）

| 指标 | 取值范围 | 说明 |
|------|---------|------|
| **F1 Score** | 0.82-0.93 | 精确率和召回率的调和平均 |
| **IoU** | 0.70-0.88 | 预测区域与真实区域的交并比 |
| **Precision** | 0.85-0.95 | 预测为着丝粒中真正是的比例 |
| **Recall** | 0.80-0.92 | 真实着丝粒中被成功预测的比例 |
| **AUC** | 0.90-0.98 | ROC曲线下面积 |

### 不同阈值的表现

| 阈值 | Precision | Recall | F1 | 适用场景 |
|------|-----------|--------|----|---------| 
| 0.2 | 较低 | 高 | 中 | 需要高召回率，不想漏掉着丝粒 |
| 0.3 | 中 | 中高 | 高 | **默认推荐**，平衡性能 |
| 0.5 | 高 | 中 | 中 | 需要高精确率，减少假阳性 |

## 适用范围

### 适用的物种/基因组

- ✅ 已在多物种基因组上测试
- ✅ 对于重复序列丰富的区域效果较好
- ✅ 适用于标准染色体结构

### 限制和注意事项

- ⚠️ 新物种可能需要调整阈值或重新训练
- ⚠️ 非常短的染色体（<100kb）可能效果不佳
- ⚠️ 极度异质的基因组可能需要专门训练
- ⚠️ 建议在自己的数据上验证后再用于正式研究

## 推理速度

### CPU

- **单个染色体** (~5Mb): ~30-60秒
- **全基因组** (~200Mb): ~10-30分钟

### GPU (CUDA)

- **单个染色体** (~5Mb): ~3-10秒
- **全基因组** (~200Mb): ~1-5分钟

*注: 速度取决于硬件配置和序列长度*

## 故障排查

### 模型加载失败

```python
# 如果出现版本不兼容问题
checkpoint = torch.load('checkpoints/best_model.pt', 
                       map_location='cpu',
                       weights_only=False)
```

### CUDA内存不足

```bash
# 使用CPU推理
python inference.py --checkpoint checkpoints/best_model.pt ... --device cpu
```

### 预测结果全为0

- 检查输入CSV格式是否正确
- 尝试降低阈值：`--threshold 0.2`
- 检查特征数值范围是否合理

## 更新日志

### v1.0.0 (2024-12-19)

- ✅ 初始发布
- ✅ 在多物种数据上训练
- ✅ 验证集F1 score > 0.85

## 引用

如果在研究中使用本模型，请引用：

```bibtex
@software{centromere_prediction_model,
  title = {Pretrained Transformer Model for Centromere Prediction},
  year = {2024},
  url = {https://github.com/yourusername/centromere_prediction}
}
```

## 许可证

本模型与代码一起遵循 MIT License。

## 联系方式

- 问题反馈: [GitHub Issues](https://github.com/yourusername/centromere_prediction/issues)
- 模型相关问题: your.email@example.com

---

**提示**: 第一次使用推荐从 [快速开始指南](../docs/QUICKSTART_CN.md) 开始！

