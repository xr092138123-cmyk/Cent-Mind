"""
Centromere Area Prediction Package
基于Transformer的着丝粒区域预测模型
"""

__version__ = "1.0.0"
__author__ = "Centromere Prediction Team"


